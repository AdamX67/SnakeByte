/**
 * Snakebyte application firewall.
 *
 * This is a browser-side, deny-by-default policy guard. It is defense in depth
 * behind the CSP and Trusted Types: it cannot control actual network packets,
 * and a determined attacker who rewrites the bundle can remove it. The host
 * firewall / WAF configuration lives in `firewall/`.
 */
const STORAGE_PREFIX = "bitarcade.snakebyte.v1.";
const BLOCK_PREFIX = "Blocked by Snakebyte firewall";

export type FirewallStatus = {
  active: boolean;
  blocked: number;
  reason: string;
  rules: string[];
};

const status: FirewallStatus = {
  active: false,
  blocked: 0,
  reason: "Not installed",
  rules: [
    "network-deny",
    "navigation-deny",
    "frame-deny",
    "secure-origin",
    "storage-prefix",
  ],
};

let installed = false;

function deny(api: string): never {
  status.blocked += 1;
  try {
    window.dispatchEvent(
      new CustomEvent("snakebyte:firewall-block", { detail: { api } }),
    );
  } catch {
    /* Event delivery must never mask the denial. */
  }
  throw new DOMException(`${BLOCK_PREFIX}: ${api}`, "SecurityError");
}

function BlockedApi(this: unknown, api: string) {
  void this;
  deny(api);
}

function guard(target: object, key: string, value: unknown) {
  try {
    Object.defineProperty(target, key, {
      value,
      writable: false,
      configurable: false,
    });
    return true;
  } catch {
    return false;
  }
}

function installStoragePrefixGuard() {
  if (typeof Storage === "undefined") return true;
  const proto = Storage.prototype as unknown as Record<string, unknown>;
  const originalGet = proto.getItem as (this: Storage, key: string) => string | null;
  const originalSet = proto.setItem as (this: Storage, key: string, value: string) => void;
  const originalRemove = proto.removeItem as (this: Storage, key: string) => void;

  const check = (api: string, key: unknown) => {
    if (typeof key !== "string" || !key.startsWith(STORAGE_PREFIX))
      deny(api);
  };
  const guardedGet = function (this: Storage, key: string) {
    check("storage.getItem", key);
    return originalGet.call(this, key);
  };
  const guardedSet = function (this: Storage, key: string, value: string) {
    check("storage.setItem", key);
    return originalSet.call(this, key, value);
  };
  const guardedRemove = function (this: Storage, key: string) {
    check("storage.removeItem", key);
    return originalRemove.call(this, key);
  };

  return (
    guard(Storage.prototype, "getItem", guardedGet) &&
    guard(Storage.prototype, "setItem", guardedSet) &&
    guard(Storage.prototype, "removeItem", guardedRemove) &&
    guard(Storage.prototype, "clear", () => deny("storage.clear"))
  );
}

/** Installs the guard before React or the integrity check runs. */
export function installAppFirewall(): FirewallStatus {
  if (installed) return getFirewallStatus();
  installed = true;

  // Development mode needs Vite's local WebSocket for hot reload.
  if (import.meta.env.DEV) {
    status.reason = "Development mode";
    return getFirewallStatus();
  }
  if (window.top !== window.self) {
    status.reason = "Cross-origin framing denied";
    return getFirewallStatus();
  }
  const localHost =
    location.protocol === "file:" ||
    location.hostname === "localhost" ||
    location.hostname === "127.0.0.1" ||
    location.hostname === "[::1]";
  if (!localHost && location.protocol !== "https:") {
    status.reason = "Insecure transport denied";
    return getFirewallStatus();
  }

  const win = window as unknown as Record<string, unknown>;
  const nav = navigator as unknown as Record<string, unknown>;
  let ok = true;
  ok = guard(win, "fetch", () => deny("fetch")) && ok;
  ok = guard(win, "XMLHttpRequest", function () { deny("XMLHttpRequest"); }) && ok;
  ok = guard(win, "WebSocket", function () { deny("WebSocket"); }) && ok;
  ok = guard(win, "EventSource", function () { deny("EventSource"); }) && ok;
  ok = guard(nav, "sendBeacon", () => deny("sendBeacon")) && ok;
  ok = guard(win, "open", () => deny("window.open")) && ok;
  ok = installStoragePrefixGuard() && ok;
  void BlockedApi;

  status.active = ok;
  status.reason = ok ? "Active" : "Partially installed";
  return getFirewallStatus();
}

export function getFirewallStatus(): FirewallStatus {
  return { ...status, rules: [...status.rules] };
}
