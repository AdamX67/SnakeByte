import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./fonts.css";
import "./index.css";
import App from "./App";
import { installAppFirewall } from "./game/firewall";
import { verifyCodeIntegrity } from "./game/integrity";

const root = createRoot(document.getElementById("root")!);

try {
  const savedTheme = JSON.parse(
    localStorage.getItem("bitarcade.snakebyte.v1.theme") || '"dark"',
  );
  if (savedTheme === "light" || savedTheme === "dark")
    document.documentElement.dataset.theme = savedTheme;
} catch {
  document.documentElement.dataset.theme = "dark";
}

async function boot() {
  installAppFirewall();
  await verifyCodeIntegrity();
  root.render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}

void boot().catch(() => {
  // The integrity guard already clears storage on failure. A final fallback
  // render keeps the cabinet available even if hashing itself is unavailable.
  root.render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
});
